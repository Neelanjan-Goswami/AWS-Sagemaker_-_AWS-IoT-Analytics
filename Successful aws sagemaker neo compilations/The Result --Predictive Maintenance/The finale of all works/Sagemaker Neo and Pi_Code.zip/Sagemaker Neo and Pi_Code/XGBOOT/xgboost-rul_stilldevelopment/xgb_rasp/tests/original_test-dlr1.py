#!/usr/bin/env python
import os
from dlr import DLRModel
import numpy as np
import time
import logging
logging.basicConfig(filename='test-dlr.log', level=logging.DEBUG)
current_milli_time = lambda: int(round(time.time() * 1000))


model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../model-rasp3b')
device = 'cpu'
model = DLRModel(model_path, device)
image = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data3.npy')).astype(np.float32)

def run_inference(image):
    x=np.array(image)
    x=np.reshape(x,(1,len(x)))
    input_data = {'data':x}
    out = model.run(input_data)
    #t2 = current_milli_time()
    #logging.debug('done m.run(), time (ms): {}'.format(t2 - t1))
    #top1 = np.argmax(out[0])
    #logging.debug('Inference result: {}, {}'.format(top1,top1))
    #import resource
    #logging.debug("peak memory usage (bytes on OS X, kilobytes on Linux) {}".format(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
    return {
    #'time': t2 - t1,
	'output': out
    }

for i in image:
    res=run_inference(i)
    print(res)
print("All tests PASSED!")