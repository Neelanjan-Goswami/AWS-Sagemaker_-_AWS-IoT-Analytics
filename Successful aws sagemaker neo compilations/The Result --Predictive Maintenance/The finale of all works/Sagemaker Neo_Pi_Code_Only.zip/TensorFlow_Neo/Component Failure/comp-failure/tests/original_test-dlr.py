import os
from dlr import DLRModel
import resource
import numpy as np
import time
import logging
from numpy import asarray
logging.basicConfig(filename='test-dlr.log', level=logging.DEBUG)
current_milli_time = lambda: int(round(time.time() * 1000))
def run_inference():
    model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../model-rasp3b')
    device = 'cpu'
    model = DLRModel(model_path,device)
    true_pred = 0
    false_pred = 0
    feats = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data_features.npy')).astype(np.float32)
    label = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data_labels.npy')).astype(np.float32)
    t1 = current_milli_time()
    for i in range(25003):
        features = {'data': feats[i]}
        out = model.run(features)
        if(label[i] == np.argmax(out)):
            true_pred +=1
        else:
            false_pred+=1
    print("Accuracy:",true_pred/25003*100)
    print(true_pred,false_pred)
    t2 = current_milli_time()
    logging.debug('done m.run(), time (ms): {}'.format(t2 - t1))
    top1 = np.argmax(out[0])
    logging.debug('Inference result: {}, {}'.format(top1,top1))
    logging.debug("peak memory usage (bytes on OS X, kilobytes on Linux) {}".format(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
    time=t2-t1
    return {
        'time': time
    }
if __name__ == '__main__':
    res = run_inference()
    print(res)
    print("All tests PASSED!")

