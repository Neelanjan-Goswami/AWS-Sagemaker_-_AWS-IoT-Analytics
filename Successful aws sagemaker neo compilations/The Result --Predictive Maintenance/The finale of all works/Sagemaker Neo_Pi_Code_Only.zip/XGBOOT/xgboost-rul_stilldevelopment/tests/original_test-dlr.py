#!/usr/bin/env python
import os
from dlr import DLRModel
import numpy as np
import time
import logging
logging.basicConfig(filename='test-dlr.log', level=logging.DEBUG)
current_milli_time = lambda: int(round(time.time() * 1000))
def run_inference():
    model_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../model-rasp3b')
    #batch_size = 1
    #channels = 3
    #height = width = 224
    #input_shape = {'data': [batch_size, channels, height, width]}
    #classes = 1000
    #output_shape = [batch_size, classes]
    device = 'cpu'
    model = DLRModel(model_path, device)
    #synset_path = os.path.join(model_path, 'synset.txt')
    #with open(synset_path, 'r') as f:
    #    synset = eval(f.read())
    image = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data3.npy')).astype(np.float32)
    input_data = {'data':image}    
    print(input_data)
	
    #for rep in range(4):
    #t1 = current_milli_time()
    #t2 = current_milli_time()
    #logging.debug('done m.run(), time (ms): {}'.format(t2 - t1))
    #top1 = np.argmax(out[0])
    #logging.debug('Inference result: {}, {}'.format(top1,top1))

    out = model.run(input_data)
    import resource
    logging.debug("peak memory usage (bytes on OS X, kilobytes on Linux) {}".format(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
    return {
        #'synset_id': top1,
        #'prediction': synset[top1],
        #'time': t2 - t1,
		'output': out
    }

if __name__ == '__main__':
	
    res = run_inference()
    print("All tests PASSED!")
